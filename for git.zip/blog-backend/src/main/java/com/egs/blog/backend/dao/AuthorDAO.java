/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.backend.dao;

import java.util.List;
import com.egs.blog.backend.entities.Author;
/**
 *
 * @author eduardm
 */
public interface AuthorDAO {
    public List<Author> getAuthorListAll();
    
    public List<Author> getAuthorList(Integer start, Integer max);

    public Long saveAuthor(Author author);

    public boolean deleteAuthor(Long id);

    public boolean updateAuthor(Author author);

    public Author getAuthorById(Long id);

    public List<Author> getAuthorsByName(String name);
}
