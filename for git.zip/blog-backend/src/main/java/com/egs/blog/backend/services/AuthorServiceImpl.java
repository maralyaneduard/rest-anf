/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.backend.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.egs.blog.backend.entities.Author;
import com.egs.blog.backend.dao.AuthorDAO;
/**
 *
 * @author eduardm
 */
@Service("authorService")
@Component
@Transactional
public class AuthorServiceImpl implements AuthorService {

    @Autowired
    private AuthorDAO authorDao;

    @Override
    public List<Author> getAuthorListAll() {
        return authorDao.getAuthorListAll();
    }

    @Override
    public List<Author> getAuthorList(Integer start, Integer max) {
        return authorDao.getAuthorList(start, max);
    }

    @Override
    public Long saveAuthor(Author author) {
        return authorDao.saveAuthor(author);
    }

    @Override
    public boolean deleteAuthor(Long id) {
        return authorDao.deleteAuthor(id);
    }

    @Override
    public boolean updateAuthor(Author author) {
        return authorDao.updateAuthor(author);
    }

    @Override
    public Author getAuthorById(Long id) {
        return authorDao.getAuthorById(id);
    }

    @Override
    public List<Author> getAuthorsByName(String name) {
        return authorDao.getAuthorsByName(name);
    }
}
