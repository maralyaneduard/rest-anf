/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.backend.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.egs.blog.backend.entities.Book;
import com.egs.blog.backend.dao.BookDAO;

/**
 * @author eduardm
 */
@Service("bookService")
@Repository
@Transactional
public class BookServiceImpl implements BookService {

    @Autowired
    private BookDAO bookDao;

    @Override
    public List<Book> getBookListAll() {
        return bookDao.getBookListAll();
    }

    @Override
    public List<Book> getBookList(Integer start, Integer max) {
        return bookDao.getBookList(start, max);
    }

    @Override
    public Long saveBook(Book book) {
        return bookDao.saveBook(book);
    }

    @Override
    public Long saveBookToAuthor(Book book, Long authorId) {
        return bookDao.saveBookToAuthor(book,authorId);
    }

    @Override
    public boolean deleteBook(Long id) {
        return bookDao.deleteBook(id);
    }

    @Override
    public boolean updateBook(Book book) {
        return bookDao.updateBook(book);
    }

    @Override
    public Book getBookById(Long id) {
        return bookDao.getBookById(id);
    }

    @Override
    public List<Book> getBooksByTitle(String title) {
        return bookDao.getBooksByTitle(title);
    }

    @Override
    public List<Book> getBooksByAuthorId(Long authorId) {
        return bookDao.getBooksByAuthorId(authorId);
    }
}
