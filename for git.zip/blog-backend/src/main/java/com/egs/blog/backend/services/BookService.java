/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.backend.services;

import com.egs.blog.backend.entities.Book;

import java.util.List;

/**
 * @author eduardm
 */
public interface BookService {
    public List<Book> getBookListAll();

    public List<Book> getBookList(Integer start, Integer max);

    public Long saveBook(Book book);

    public Long saveBookToAuthor(Book book,Long authorId);

    public boolean deleteBook(Long id);

    public boolean updateBook(Book book);

    public Book getBookById(Long id);

    public List<Book> getBooksByTitle(String title);

    public List<Book> getBooksByAuthorId(Long authorId);
}
