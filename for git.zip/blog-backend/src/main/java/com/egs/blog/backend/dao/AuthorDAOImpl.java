/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.backend.dao;

import java.util.List;
import org.hibernate.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.egs.blog.backend.entities.Author;
/**
 *
 * @author eduardm
 */
@Component
@Repository("authorDAO")
public class AuthorDAOImpl extends AbstractDAO implements AuthorDAO{

    @Override
    public List<Author> getAuthorListAll() {
        List<Author> finalList = null;
        try {
            Query query = getSession().createQuery("FROM Author");
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;
    }

    @Override
    public List<Author> getAuthorList(Integer start, Integer max) {
        List<Author> finalList = null;
        try {
            Query query = getSession().createQuery("FROM Author");
            if (start != null) {
                query.setFirstResult(start);
            }
            if (max != null) {
                query.setMaxResults(max);
            }
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;
    }

    @Override
    public Long saveAuthor(Author author) {
        Long id = 0L;
        getSession().save(author);
        getSession().flush();
        id = author.getId();
        return id;
    }

    @Override
    public boolean deleteAuthor(Long id) {
        if (id != null) {
            Author author = this.getAuthorById(id);
            if (author != null) {
                Query query = getSession().createQuery("delete Book b where b.author.id = :id").setParameter("id", author.getId());
                int result = query.executeUpdate();
                getSession().delete(author);
            }
        } else {
            return false;
        }
        return true;
    }

    @Override
    public boolean updateAuthor(Author author) {
        if (author != null) {
            getSession().update(author);
        } else {
            return false;
        }
        return true;
    }

    @Override
    public Author getAuthorById(Long id) {
        Author entity = null;
        try {
            Query query = getSession().createQuery("SELECT a FROM Author a WHERE a.id=:id").setParameter("id", id);
            entity = (Author) query.uniqueResult();
            if (entity == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return entity;
    }

    @Override
    public List<Author> getAuthorsByName(String name) {
        List<Author> finalList = null;
        try {
            Query query = getSession().createQuery("SELECT a FROM Author a where a.name LIKE :name").setParameter("name", "%" + name + "%");
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;}
}
