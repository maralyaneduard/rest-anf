/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.backend.dao;

import java.util.List;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.egs.blog.backend.entities.Book;
/**
 *
 * @author eduardm
 */
@Component
@Repository("bookDAO")
public class BookDAOImpl extends AbstractDAO implements BookDAO{

    @Autowired
    private AuthorDAO authorDAO;

    @Override
    public List<Book> getBookListAll() {
        List<Book> finalList = null;
        try {
            Query query = getSession().createQuery("FROM Book");
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;
    }

    @Override
    public List<Book> getBookList(Integer start, Integer max) {
        List<Book> finalList = null;
        try {
            Query query = getSession().createQuery("FROM Book");
            if (start != null) {
                query.setFirstResult(start);
            }
            if (max != null) {
                query.setMaxResults(max);
            }
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;
    }

    @Override
    public Long saveBook(Book book) {
        Long id = 0L;
        getSession().save(book);
        getSession().flush();
        id = book.getId();
        return id;
    }

    @Override
    public Long saveBookToAuthor(Book book, Long authorId) {
        Long id = 0L;
        if(authorId != null)
        {
            book.setAuthor(authorDAO.getAuthorById(authorId));
            getSession().save(book);
            getSession().flush();
            id = book.getId();
        }
        return id;
    }

    @Override
    public boolean deleteBook(Long id) {
        if (id != null) {
            Book book = this.getBookById(id);
            if (book != null) {
                getSession().delete(book);
            }
        } else {
            return false;
        }
        return true;
    }

    @Override
    public boolean updateBook(Book book) {
        if (book != null) {
            getSession().update(book);
        } else {
            return false;
        }
        return true;
    }

    @Override
    public Book getBookById(Long id) {
        Book entity = null;
        try {
            Query query = getSession().createQuery("SELECT b FROM Book b WHERE b.id=:id").setParameter("id", id);
            entity = (Book) query.uniqueResult();
            if (entity == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return entity;
    }

    @Override
    public List<Book> getBooksByTitle(String title) {
        List<Book> finalList = null;
        try {
            Query query = getSession().createQuery("SELECT b FROM Book b where b.title LIKE :title").setParameter("title", "%" + title + "%");
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;
    }

    @Override
    public List<Book> getBooksByAuthorId(Long authorId) {
        List<Book> finalList = null;
        try {
            Query query = getSession().createQuery("SELECT b FROM Book b where b.author.id LIKE :authorId").setParameter("authorId",authorId);
            finalList = query.list();
            if (finalList == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalList;
    }
}
