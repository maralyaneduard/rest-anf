package com.egs.blog.rest;

import com.egs.blog.backend.entities.Author;
import com.egs.blog.backend.entities.Book;
import com.egs.blog.backend.services.BookService;
import com.sun.research.ws.wadl.HTTPMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by eduardm on 8/24/16.
 */
@RestController
@RequestMapping(value = "/books")
public class BookController {

    @Autowired
    private BookService bookService;
    @Autowired
    private HttpSession httpSession;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseEntity<List<Book>> getBooksByTitle(@RequestParam(value = "title", defaultValue = "") String title) {
        Object o = httpSession.getAttribute("user");
        return new ResponseEntity<List<Book>>(bookService.getBooksByTitle(title), HttpStatus.OK);
    }

    @RequestMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Long id) {

        return new ResponseEntity<Book>(bookService.getBookById(id), HttpStatus.OK);
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Long id = bookService.saveBook(book);
        return new ResponseEntity<Book>(bookService.getBookById(id), HttpStatus.CREATED);
    }

    @RequestMapping(value = "", method = RequestMethod.PUT)
    public ResponseEntity updateBook(@RequestBody Book book) {
        if (bookService.updateBook(book)) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity deleteBook(@PathVariable Long id) {
        if (bookService.deleteBook(id)) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}