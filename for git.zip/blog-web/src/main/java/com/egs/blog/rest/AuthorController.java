package com.egs.blog.rest;

import com.egs.blog.backend.entities.Author;
import com.egs.blog.backend.entities.Book;
import com.egs.blog.backend.services.AuthorService;
import com.egs.blog.backend.services.BookService;
import com.egs.blog.utils.ParamUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by eduardm on 8/24/16.
 */
@RestController
@RequestMapping(value = "/authors")
public class AuthorController {

    @Autowired
    private AuthorService authorService;
    @Autowired
    private BookService bookService;
    @Autowired
    private HttpSession httpSession;

    @RequestMapping("")
    public ResponseEntity<List<Author>> getAllAuthors() {
        return new ResponseEntity<List<Author>>(authorService.getAuthorListAll(),HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<Author> getAuthorById(@PathVariable Long id) {
        return new ResponseEntity<Author>(authorService.getAuthorById(id), HttpStatus.OK);
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    public  ResponseEntity<Author> addAuthor(@RequestBody Author author) {
        Long id = authorService.saveAuthor(author);
        return new ResponseEntity<Author>(authorService.getAuthorById(id),HttpStatus.CREATED);
    }

    @RequestMapping(value = "", method = RequestMethod.PUT)
    public ResponseEntity updateAuthor(@RequestBody Author author) {
        if (authorService.updateAuthor(author)) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }
        else
        {
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity deleteAuthor(@PathVariable Long id) {
        if (authorService.deleteAuthor(id)) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }
        else
        {
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/{id}/books", method = RequestMethod.GET)
    public ResponseEntity<List<Book>> getAuthorsBooks(@PathVariable Long id) {
        return new ResponseEntity<List<Book>>(bookService.getBooksByAuthorId(id),HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}/books", method = RequestMethod.POST)
    public ResponseEntity<List<Book>> saveAuthorsBook(@RequestBody Book book ,@PathVariable Long id) {
        Long bookId =bookService.saveBookToAuthor(book,id);
        if(bookId != 0L)
        {
            return new ResponseEntity<List<Book>>(bookService.getBooksByAuthorId(id),HttpStatus.CREATED);
        }
        else
        {
            return new ResponseEntity<List<Book>>(new ArrayList<Book>(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/{authorId}/books/{bookId}", method = RequestMethod.PUT)
    public ResponseEntity<Boolean> editAuthorsBook(@RequestBody Book book ,@PathVariable Long authorId , @PathVariable Long bookId) {
        book.setId(bookId);
        book.setAuthor(authorService.getAuthorById(authorId));
        if(bookId != 0L)
        {
            return new ResponseEntity<Boolean>(bookService.updateBook(book),HttpStatus.CREATED);
        }
        else
        {
            return new ResponseEntity<Boolean>(false,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}