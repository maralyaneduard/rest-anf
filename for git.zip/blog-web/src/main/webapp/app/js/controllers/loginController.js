/**
 * Created by eduardm on 8/25/16.
 */
app.controller("loginController", function ($scope, $http, $routeParams, $location, $route, loginService) {
    $scope.loginUser = {
        email:"",
        password:""
    }

    $scope.registerUser = {
        email:"",
        password:"",
        firstname:"",
        lastname:"",
        username:""
    }

    $scope.login = function(){
        loginService.login($http, $location, $scope.loginUser).then(
            function (result) {
                $location.path("/books");
            }
        )
    }

    $scope.register = function(){
        loginService.register($http, $location, $scope.registerUser).then(
            function (result) {
                $location.path("/books");
            }
        )
    }

    $scope.logOut = function(){
        loginService.logOut($http, $location).then(
            function (result) {
                $location.path("/");
            }
        )
    }
});