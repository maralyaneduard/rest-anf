/**
 * Created by eduardm on 8/25/16.
 */
"use strict";

app.controller("bookController", function ($scope, $http, $routeParams, $location, $route, bookService, authorService) {

    var newBook = {
        title: "",
        description: ""
    }
    var authorId = 0;
    $scope.selectedAuthor = undefined;
    $scope.newBook = newBook;
    $scope.editBookId = $routeParams.bookId;

    if($scope.editBookId != undefined)
    {
        bookService.getBookById($http, $location,$scope.editBookId).then(
            function (result) {
                $scope.newBook = result;
            }
        );
    }

    authorService.getAllAuthors($http, $location).then(
        function (result) {
            $scope.authors = result;
        }
    );

    bookService.getAllBooks($http, $location).then(
        function (result) {
            if (result[0] == undefined) {
                $scope.hasNoItems = true;
            }
            else {
                $scope.books = result;
                $scope.hasItems = true;
                $scope.hasNoItems = false;
            }
        }
    );

    $scope.deleteBook = function (id) {
        bookService.deleteBook($http, $location, id).then(
            function (result) {
                $route.reload();
            }
        );
    }

    $scope.saveBook = function () {
        bookService.createBook($http, $location, newBook, $scope.selectedAuthor.id).then(
            function (result) {
                $location.path("/books");
            }
        )
    }

    $scope.editBook = function (bookId) {
        bookService.editBook($http, $location, $scope.newBook, $scope.selectedAuthor.id,bookId).then(
            function (result) {
                $location.path("/books");
            }
        )
    }
});