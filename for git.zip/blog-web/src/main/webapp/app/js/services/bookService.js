/**
 * Created by eduardm on 8/25/16.
 */
app.service("bookService", function () {

    var path = "rest/books";
    var addBookPath = "rest/authors";

    this.getAllBooks = function ($http, $location) {
        var url = getContext($location) + path;
        return $http.get(url).then(handleSuccess, handleError("Error whilte getting books"));
    }

    this.getBookById = function ($http, $location,id) {
        var url = getContext($location) + path + "/" + id;
        return $http.get(url).then(handleSuccess, handleError("Error whilte getting the book"));
    }

    this.deleteBook = function ($http, $location, id) {
        var url = getContext($location) + path + "/" + id;
        return $http.delete(url).then(handleSuccess, handleError("Error while trying to delete"));
    }

    this.createBook = function ($http, $location, book , id) {
        var url = getContext($location) + addBookPath + "/" + id + "/" + "books/";
        return $http.post(url, JSON.stringify(book)).then(handleSuccess, handleError("Error while trying to create a book"));
    }

    this.editBook = function ($http, $location, book , authorId, bookId) {
        var url = getContext($location) + addBookPath + "/" + authorId + "/" + "books/" + bookId;
        return $http.put(url, JSON.stringify(book)).then(handleSuccess, handleError("Error while trying to edit a book"));
    }

    function handleError(error) {
        return function () {
            return {
                success: false,
                message: error
            };
        };
    }

    function handleSuccess(res) {
        return res.data;
    }

    function getContext($location) {
        if (document.location.hostname == "localhost") {
            var pathArray = location.href.split("/");
            var protocol = pathArray[0];
            var host = pathArray[2];
            return protocol + "//" + host + "/";
        }
        return "/";
    }
});