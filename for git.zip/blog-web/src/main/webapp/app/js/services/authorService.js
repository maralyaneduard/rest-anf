/**
 * Created by eduardm on 8/25/16.
 */

app.service("authorService", function () {

    var path = "rest/authors";

    this.getAllAuthors = function ($http, $location) {
        var url = getContext($location) + path;
        return $http.get(url).then(handleSuccess, handleError("Error whilte getting authors"));
    }

    function handleError(error) {
        return function () {
            return {
                success: false,
                message: error
            };
        };
    }

    function handleSuccess(res) {
        return res.data;
    }

    function getContext($location) {
        if (document.location.hostname == "localhost") {
            var pathArray = location.href.split("/");
            var protocol = pathArray[0];
            var host = pathArray[2];
            return protocol + "//" + host + "/";
        }
        return "/";
    }
});
