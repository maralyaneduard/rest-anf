/**
 * Created by eduardm on 8/24/16.
 */
var app = angular.module("libraryApp", ["ngRoute"]);

app.config(function ($routeProvider) {
    $routeProvider
        .when("/books", {
            templateUrl: "app/views/book/books.html",
            controller: "bookController"
        }).when("/createBook", {
        templateUrl: "app/views/book/createBook.html",
        controller: "bookController"
    }).when("/editBook/:bookId?/", {
        templateUrl: "app/views/book/editBook.html",
        controller: "bookController"
    }).when("/login", {
        templateUrl: "app/views/login.html",
        controller: "loginController"
    }).when("/register", {
        templateUrl: "app/views/register.html",
        controller: "loginController"
    }).otherwise({
        redirectTo: "/books",
        controller: "bookController"
    });
});